# spot-social-nav
Boston Dynamics Spot Robot Social Navigation
